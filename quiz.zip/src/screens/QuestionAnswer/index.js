import React, { useState } from "react";
import { CButton, CCol, CContainer, CRow } from "@coreui/react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import { toast } from "react-toastify";
import Info from "../../components/Info";
import TabsComponent from "../../components/Tabs";
import formStructure from "../../components/Form";
import { Fonts } from "../../Utils/Fonts";
import Images from "../../Utils/Images";

// Styles
const styles = {
  formContainer: { textAlign: "center" },
  header: {
    display: "flex",
    justifyContent: "space-between",
    color: "white",
    borderRadius: "10px",
  },
  logo: {
    display: "flex",
    alignItems: "center",
    fontSize: "2rem",
    fontWeight: "bold",
  },
  text: {
    fontSize: "16px",
    ...Fonts.Inter,
    fontWeight: 400,
    textAlign: "justify",
  },
  container: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 50,
    padding: 20,
    textAlign: "center",
  },
  button: { backgroundColor: "#0048ff", color: "white" },
  formContent: {
    backgroundColor: "white",
    padding: "30px",
    borderRadius: "10px",
    boxShadow: "0 4px 10px rgba(0, 0, 0, 0.1)",
    textAlign: "left",
    marginTop:20
  },
};

// Header Component
const Header = ({ isMobile }) => (
  <CRow
    lg={12}
    md={6}
    sm={3}
    style={{ ...styles.header, flexDirection: "row-reverse" }}
  >
    <CCol sm={6} md={6} lg={6}>
      <img src={Images.head} style={{ width: "100%", height: "auto" }} />
    </CCol>
    <CCol
      sm={3}
      md={4}
      lg={3}
      style={{
        ...styles.logo,
        justifyContent: "center",
        marginTop: isMobile ? 20 : 0,
      }}
    >
      <img
        src={Images.logoBig}
        style={{
          width: isMobile ? "50%" : "100%",
          height: "auto",
          maxWidth: "400px",
        }}
      />
    </CCol>
  </CRow>
);

// Quiz Component
const Quiz = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const isMobile = window.innerWidth <= 767;

  // State Variables
  const [responses, setResponses] = useState({});
  const [personalInfo, setPersonalInfo] = useState({});
  const [currentTab, setCurrentTab] = useState(0);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const API_BASE_URL = "http://quiz.spectrumenterprises.com.pk/api";

  // Update Personal Info
  const handlePersonalInfoChange = (field, value) => {
    setPersonalInfo((prev) => ({ ...prev, [field]: value }));
  };

  // Update Question Responses
  const handleInputChange = (questionId, value) => {
    setResponses((prev) => ({ ...prev, [questionId]: value }));
  };

  // Navigation for Tabs
  const handleNavigation = (direction) => {
    if (!validateFields()) return;
    setCurrentTab((prev) => (direction === "next" ? prev + 1 : prev - 1));
    window.scrollTo({ top: 400, behavior: "smooth" });
  };

  // Validate Fields
  const validateFields = () => {
    const currentSection = formStructure[currentTab];
    const newErrors = {};

    if (currentTab === 0) {
      if (!personalInfo.firstName)
        newErrors.firstName = "First name is required.";
      if (!personalInfo.email) newErrors.email = "Email is required.";
      if (!personalInfo.date) newErrors.date = "Date is required.";
    } else {
      currentSection.questions.forEach((q) => {
        if (q.isRequired && !responses[q.id]) {
          newErrors[q.id] = `${q.questionText} is required.`;
        }
      });
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Render Questions
  const renderQuestions = (questions) =>
    questions.map((q) => (
      <div key={q.id} style={{ margin: "20px", ...styles.text }}>
        <p>{q.questionText}</p>
        {renderInputField(q)}
        {errors[q.id] && <p style={{ color: "red",fontSize:14 }}>{/*errors[q.id]*/ 'please fill this field'}</p>}
      </div>
    ));

  // Render Input Fields
  const renderInputField = (q) => {
    switch (q.questionType) {
      case "mcq":
        return q.options.map((o, idx) => (
          <label key={idx} style={{ ...styles.answerFont, margin: 5 }}>
            <input
              type="radio"
              name={`${q.id}`}
              value={o.answer}
              checked={responses[q.id] === o.answer}
              onChange={() => handleInputChange(q.id, o.answer)}
              style={{ marginRight: 10 }}
            />
            {o.answer}
          </label>
        ));
      case "text":
        return (
          <textarea
            style={{
              ...styles.answerText,
              width: isMobile ? "200px" : "632px",
            }}
            value={responses[q.id] || ""}
            onChange={(e) => handleInputChange(q.id, e.target.value)}
          />
        );
      case "multicheck":
        return q.options.map((o, idx) => (
          <label key={idx} style={{ margin: "10px", ...styles.text }}>
            <input
              type="checkbox"
              value={o.answer}
              checked={responses[q.id]?.includes(o.answer)}
              onChange={(e) => handleCheckboxChange(q.id, e, o.answer)}
              style={{ marginRight: 10 }}
            />
            {o.answer}
          </label>
        ));
      default:
        return null;
    }
  };

  // Handle Checkbox Input Change
  const handleCheckboxChange = (questionId, e, answer) => {
    const selected = responses[questionId] || [];
    const newResponses = e.target.checked
      ? [...selected, answer]
      : selected.filter((item) => item !== answer);
    handleInputChange(questionId, newResponses);
  };

  // Submit Form
  const handleSubmit = async () => {
    if (!validateFields()) return;
    setIsSubmitting(true);

    try {
      const payload = { employee_info: JSON.stringify(personalInfo) };
      const response = await axios.post(
        `${API_BASE_URL}/assessment/submitAssessment/${slug}`,
        payload
      );

      if (response.data) {
        navigate(`/response/${response.data.assessment_id}`);
      } else {
        toast.error("Submission failed.");
      }
    } catch (error) {
      toast.error("Submission failed.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <CContainer>
      {/* Header */}
      <Header isMobile={isMobile} />

      {/* Intro Text */}
      <CCol style={styles.container}>
        <p style={styles.text}>
          Mentor Health is your dedicated health partner. Your well-being is our
          priority. Please take just 5 minutes out of your day to fill out this
          form. This personalized health journey is designed to evaluate your
          risks, understand your health needs, and maximize health benefits.
          Through this collaboration, we'll develop strategies to reduce your
          health costs and promote healthy living through preventive care.
          Together, we can ensure you lead a healthier, happier life.
        </p>
      </CCol>

      {/* Tabs Navigation */}
      <TabsComponent
        currentTab={currentTab}
        formStructure={formStructure}
        handleTabClick={setCurrentTab}
      />

      {/* Form Content */}
      <CContainer style={styles.formContent}>
        {currentTab === 0 ? (
          <Info
            onInputChange={handlePersonalInfoChange}
            personalInfo={personalInfo}
          />
        ) : (
          renderQuestions(formStructure[currentTab]?.questions || [])
        )}

        {/* Navigation Buttons */}
        <CRow className="d-flex justify-content-end">
          {currentTab > 0 && (
            <CCol lg={11}>
              <CButton
                style={styles.button}
                onClick={() => handleNavigation("previous")}
                disabled={isSubmitting}
              >
                Previous
              </CButton>
            </CCol>
          )}
          <CCol>
            <CButton
              style={styles.button}
              onClick={
                currentTab === formStructure.length - 1
                  ? handleSubmit
                  : () => handleNavigation("next")
              }
              disabled={isSubmitting}
            >
              {currentTab === formStructure.length - 1 ? "Submit" : "Next"}
            </CButton>
          </CCol>
        </CRow>
      </CContainer>
    </CContainer>
  );
};

export default Quiz;
