export default{
    primary:'#0046ff',
    secondary: '#be3326',
  black: '#000',
  white: '#fff',
  gray:'#d9d9d9',
  borderGray: '#8d8787',
  fontGray:'#a3aed0',
  red:'#DF0404',
  green:'#00AC4F',
  purple:'#A43DFF',
  yellow:'#E4E414',
  chartGray:'#F1F1F1',
  barBorder:'#2B3674',
  barBorderRed:'#6D0707',
  barBorderPurple:'#7A1ECA',
  barBorderYellow:'#A5A50C',
  barBorderGreen:'#124127'
  }