// globalFonts.js
export const Fonts = {
    Poppins: {
      fontFamily: 'Poppins',
    },
    Inter:{
        fontFamily:'Inter',
    },
    Sans:{
        fontFamily:'Sans'
    },
    Roboto:{
        fontFamily:'Roboto'
    },
    
  };
  